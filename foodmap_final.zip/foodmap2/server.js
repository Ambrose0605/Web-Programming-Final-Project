const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const dotenv = require("dotenv");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

dotenv.config();

const User = require("./models/User");
const Review = require("./models/Review");

const app = express();

// ===== Middleware =====
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

// ===== Static (public/foodmap.html) =====
app.use(express.static(path.join(__dirname, "public")));

// ===== DB Connect =====
async function connectDB() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error("❌ 缺少 MONGO_URI，請在 .env 設定");
    process.exit(1);
  }
  await mongoose.connect(uri);
  console.log("✅ MongoDB connected");
}
connectDB().catch((e) => {
  console.error("❌ MongoDB connect failed:", e);
  process.exit(1);
});

// ===== Helpers =====
function signToken(user) {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("Missing JWT_SECRET in .env");
  }
  return jwt.sign(
    { userId: user._id.toString(), username: user.username },
    secret,
    { expiresIn: "7d" }
  );
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ message: "No token" });

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { userId, username }
    next();
  } catch (e) {
    return res.status(401).json({ message: "Invalid token" });
  }
}

// ===== Models (Favorite 用 server.js 內建，避免你多一個檔案) =====
const FavoriteSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    storeKey: { type: String, required: true, index: true },
    storeName: { type: String, default: "" },
    district: { type: String, default: "" },
  },
  { timestamps: true }
);
// 同一個人同一間店只能收藏一次
FavoriteSchema.index({ userId: 1, storeKey: 1 }, { unique: true });

const Favorite = mongoose.model("Favorite", FavoriteSchema);

// =======================
// Auth APIs
// =======================

// 註冊
app.post("/api/auth/register", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");

    if (username.length < 3) {
      return res.status(400).json({ message: "帳號至少 3 個字" });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: "密碼至少 6 個字" });
    }

    const exists = await User.findOne({ username });
    if (exists) {
      return res.status(400).json({ message: "此帳號已被註冊" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ username, passwordHash });

    const token = signToken(user);
    return res.json({
      token,
      user: { username: user.username, id: user._id },
    });
  } catch (e) {
    return res.status(500).json({ message: "Register failed" });
  }
});

// 登入
app.post("/api/auth/login", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");

    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ message: "帳號或密碼錯誤" });

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(400).json({ message: "帳號或密碼錯誤" });

    const token = signToken(user);
    return res.json({
      token,
      user: { username: user.username, id: user._id },
    });
  } catch (e) {
    return res.status(500).json({ message: "Login failed" });
  }
});

// 檢查登入
app.get("/api/auth/me", authMiddleware, async (req, res) => {
  return res.json({ user: { username: req.user.username } });
});

// 修改密碼（要原密碼）
app.post("/api/auth/change-password", authMiddleware, async (req, res) => {
  try {
    const oldPassword = String(req.body.oldPassword || "");
    const newPassword = String(req.body.newPassword || "");

    if (newPassword.length < 6) {
      return res.status(400).json({ message: "新密碼至少 6 個字" });
    }

    const user = await User.findById(req.user.userId);
    if (!user) return res.status(401).json({ message: "User not found" });

    const ok = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!ok) return res.status(400).json({ message: "原密碼錯誤" });

    user.passwordHash = await bcrypt.hash(newPassword, 10);
    await user.save();

    return res.json({ message: "Password updated" });
  } catch (e) {
    return res.status(500).json({ message: "Change password failed" });
  }
});

// =======================
// Favorites APIs
// =======================

// 取得我的收藏
app.get("/api/favorites", authMiddleware, async (req, res) => {
  try {
    const favorites = await Favorite.find({ userId: req.user.userId })
      .sort({ createdAt: -1 })
      .lean();
    return res.json({ favorites });
  } catch (e) {
    return res.status(500).json({ message: "Favorites read failed" });
  }
});

// 新增收藏
app.post("/api/favorites", authMiddleware, async (req, res) => {
  try {
    const storeKey = String(req.body.storeKey || "").trim();
    const storeName = String(req.body.storeName || "").trim();
    const district = String(req.body.district || "").trim();

    if (!storeKey) return res.status(400).json({ message: "storeKey required" });

    const fav = await Favorite.create({
      userId: req.user.userId,
      storeKey,
      storeName,
      district,
    });

    return res.json({ favorite: fav });
  } catch (e) {
    if (String(e.message).includes("E11000")) {
      return res.status(400).json({ message: "已經收藏過囉～" });
    }
    return res.status(500).json({ message: "Favorite failed" });
  }
});

// 移除收藏（用 query storeKey）
app.delete("/api/favorites", authMiddleware, async (req, res) => {
  try {
    const storeKey = String(req.query.storeKey || "").trim();
    if (!storeKey) return res.status(400).json({ message: "storeKey required" });

    await Favorite.deleteOne({ userId: req.user.userId, storeKey });
    return res.json({ message: "Favorite removed" });
  } catch (e) {
    return res.status(500).json({ message: "Remove favorite failed" });
  }
});

// =======================
// Reviews APIs
// =======================

// 列出某店評論
app.get("/api/reviews", async (req, res) => {
  try {
    const storeKey = String(req.query.storeKey || "").trim();
    if (!storeKey) return res.status(400).json({ message: "storeKey required" });

    const reviews = await Review.find({ storeKey })
      .sort({ createdAt: -1 })
      .select("storeKey storeName district rating comment userName createdAt")
      .lean();

    return res.json({ reviews });
  } catch (e) {
    return res.status(500).json({ message: "Reviews read failed" });
  }
});

// 新增評論（必須登入）
app.post("/api/reviews", authMiddleware, async (req, res) => {
  try {
    const storeKey = String(req.body.storeKey || "").trim();
    const storeName = String(req.body.storeName || "").trim();
    const district = String(req.body.district || "").trim();
    const rating = Number(req.body.rating || 0);
    const comment = String(req.body.comment || "").trim();

    if (!storeKey) return res.status(400).json({ message: "storeKey required" });
    if (!comment) return res.status(400).json({ message: "comment required" });
    if (!(rating >= 1 && rating <= 5)) return res.status(400).json({ message: "rating 1~5" });

    const review = await Review.create({
      storeKey,
      storeName,
      district,
      rating,
      comment,
      userId: req.user.userId,
      userName: req.user.username, // ✅ 用 token 的 username，前端不可改
    });

    return res.json({ review });
  } catch (e) {
    return res.status(500).json({ message: "Review post failed" });
  }
});

// 某店評論摘要（平均 & 數量）
app.get("/api/reviews/summary", async (req, res) => {
  try {
    const storeKey = String(req.query.storeKey || "").trim();
    if (!storeKey) return res.status(400).json({ message: "storeKey required" });

    const agg = await Review.aggregate([
      { $match: { storeKey } },
      {
        $group: {
          _id: "$storeKey",
          avgRating: { $avg: "$rating" },
          count: { $sum: 1 },
        },
      },
    ]);

    if (agg.length === 0) return res.json({ avgRating: 0, count: 0 });

    return res.json({
      avgRating: agg[0].avgRating || 0,
      count: agg[0].count || 0,
    });
  } catch (e) {
    return res.status(500).json({ message: "Summary failed" });
  }
});

// ✅ 我的評論（個人檔案用）
app.get("/api/reviews/mine", authMiddleware, async (req, res) => {
  try {
    const reviews = await Review.find({ userId: req.user.userId })
      .sort({ createdAt: -1 })
      .select("storeKey storeName district rating comment createdAt")
      .lean();

    return res.json({ reviews });
  } catch (e) {
    return res.status(500).json({ message: "Mine failed" });
  }
});

// =======================
// Rankings APIs (30天 Top10)
// =======================
app.get("/api/rankings/top", async (req, res) => {
  try {
    const now = new Date();
    const from = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const rankings = await Review.aggregate([
      { $match: { createdAt: { $gte: from } } },
      {
        $group: {
          _id: "$storeKey",
          storeKey: { $first: "$storeKey" },
          storeName: { $first: "$storeName" },
          district: { $first: "$district" },
          avgRating: { $avg: "$rating" },
          count: { $sum: 1 },
        },
      },
      // 至少 1 則評論才上榜（本來就會）
      { $sort: { avgRating: -1, count: -1 } },
      { $limit: 10 },
      {
        $project: {
          _id: 0,
          storeKey: 1,
          storeName: 1,
          district: 1,
          avgRating: { $round: ["$avgRating", 2] },
          count: 1,
        },
      },
    ]);

    return res.json({ rankings });
  } catch (e) {
    return res.status(500).json({ message: "Rankings failed" });
  }
});

// ===== Home route (optional) =====
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "foodmap.html"));
});

// ===== Start =====
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running: http://localhost:${PORT}`);
});