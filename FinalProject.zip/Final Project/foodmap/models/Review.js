// foodmap/models/Review.js
const mongoose = require("mongoose");

const ReviewSchema = new mongoose.Schema(
  {
    storeKey: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    userName: {
      type: String,
      required: true,
      trim: true,
      maxlength: 50,
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },
    comment: {
      type: String,
      required: true,
      trim: true,
      maxlength: 2000,
    },
  },
  {
    timestamps: true, // createdAt / updatedAt
  }
);

// 加速查詢：同店家按時間排序
ReviewSchema.index({ storeKey: 1, createdAt: -1 });

module.exports = mongoose.model("Review", ReviewSchema);
