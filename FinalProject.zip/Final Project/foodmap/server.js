// foodmap/server.js
require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Review = require("./models/Review");

const app = express();
const PORT = process.env.PORT || 3000;

// ---- Middleware ----
app.use(express.json());

// 靜態檔案：public 裡的 html/css/js
app.use(express.static(path.join(__dirname, "public")));

// ---- MongoDB connect ----
async function connectDB() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error("❌ 缺少 MONGO_URI，請在 .env 設定");
    process.exit(1);
  }

  try {
    await mongoose.connect(uri);
    console.log("✅ MongoDB connected");
  } catch (err) {
    console.error("❌ MongoDB connect error:", err);
    process.exit(1);
  }
}

// ---- Routes ----

// 健康檢查
app.get("/api/health", (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// 新增評論
app.post("/api/reviews", async (req, res) => {
  try {
    const { storeKey, userName, rating, comment } = req.body || {};

    // 基本檢查
    if (!storeKey || !userName || !comment) {
      return res.status(400).send("缺少必要欄位：storeKey / userName / comment");
    }

    const r = Number(rating);
    if (!Number.isFinite(r) || r < 1 || r > 5) {
      return res.status(400).send("rating 必須是 1~5");
    }

    const doc = await Review.create({
      storeKey: String(storeKey).trim(),
      userName: String(userName).trim(),
      rating: r,
      comment: String(comment).trim(),
    });

    res.status(201).json(doc);
  } catch (err) {
    console.error("POST /api/reviews error:", err);
    res.status(500).send("伺服器錯誤：新增評論失敗");
  }
});

// 取得某店家評論列表（依時間新到舊）
app.get("/api/reviews", async (req, res) => {
  try {
    const storeKey = String(req.query.storeKey || "").trim();
    if (!storeKey) return res.status(400).send("缺少 storeKey");

    const data = await Review.find({ storeKey })
      .sort({ createdAt: -1 })
      .lean();

    res.json(data);
  } catch (err) {
    console.error("GET /api/reviews error:", err);
    res.status(500).send("伺服器錯誤：讀取評論失敗");
  }
});

// 取得 summary：平均分數 + 評論數
app.get("/api/reviews/summary", async (req, res) => {
  try {
    const storeKey = String(req.query.storeKey || "").trim();
    if (!storeKey) return res.status(400).send("缺少 storeKey");

    const result = await Review.aggregate([
      { $match: { storeKey } },
      {
        $group: {
          _id: "$storeKey",
          count: { $sum: 1 },
          avgRating: { $avg: "$rating" },
        },
      },
    ]);

    if (!result || result.length === 0) {
      return res.json({ storeKey, count: 0, avgRating: 0 });
    }

    res.json({
      storeKey,
      count: result[0].count || 0,
      avgRating: result[0].avgRating || 0,
    });
  } catch (err) {
    console.error("GET /api/reviews/summary error:", err);
    res.status(500).send("伺服器錯誤：讀取 summary 失敗");
  }
});

// ---- Fallback：如果你想直接 / 打開 foodmap.html（可選） ----
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "foodmap.html"));
});

// ---- Start ----
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
  });
});